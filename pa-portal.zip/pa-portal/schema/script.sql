# 应用类型表
drop table if exists app;
create table app
(
	id int(11) auto_increment,
	name varchar(128),
	`type` enum('OS', 'APP', 'NET'),
	tpl_id int,
	creater	varchar(128),
	primary key (`id`)
) 
  ENGINE =InnoDB
  DEFAULT CHARSET =utf8
  COLLATE =utf8_unicode_ci;

# 模块、对于应用类型表
drop table if exists tpl_app;
create table tpl_app
(
	id int(11) auto_increment,
	tpl_id int(11),
	app_id int(11),
	primary key (`id`)
) 
  ENGINE =InnoDB
  DEFAULT CHARSET =utf8
  COLLATE =utf8_unicode_ci;

