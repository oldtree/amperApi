# -*- coding:utf-8 -*-

from web import app
from flask import request, jsonify
import json
import time
import requests
from web.model.host import Host
from web.model.group_host import GroupHost
from web.model.grp_tpl import GrpTpl
from web.model.strategy import Strategy
from web.model.template import Template
from web.model.tpl_app import TplApp
from web.model.app import App
from web.model.action import Action
from web.model.team import Team
from web.model.user import User
from web.model.team_user import TeamUser
from web.model.alert import Alert
from web.model.metric_info import MetricInfo
from web.model.screen import Screen
from web.model.graph import Graph
from web.model import pa_business
from frame import utils
from frame import config

@app.route('/api/version', methods=['GET', 'POST'])
def api_version():
	return '0.0.1'

@app.route('/api/health', methods=['GET', 'POST'])
def api_health():
	return 'ok'

@app.route('/api/query_strategy', methods=['POST'])
def query_strategy():
	endpoints = request.get_json(force=True)
	result = pa_business.query_strategy(endpoints)
	return json.dumps(result)

@app.route('/api/query_strategy_by_key', methods=['POST'])
def query_strategy_by_key():
	req_data = request.get_json(force=True)
	endpoint = req_data["host"]
	metric_key = req_data["metric_key"]
	page_size = req_data["page_size"]
	current_page = req_data["current_page"]
	result = pa_business.query_strategy_by_key(endpoint, metric_key, page_size, current_page)
	return json.dumps(result)

@app.route('/api/update_strategy', methods=['POST'])
def update_strategy():
	req_data = request.get_json(force=True)
	for one_host in req_data:
		endpoint = one_host["host"]
		for tpl in one_host["templates"]:
			tpl_id = tpl["tpl_id"]
			grp_id = tpl["grp_id"]

			# 如果tpl_id不在grp_tpl里，则不修改它
			grp_tpls = GrpTpl.grp_tpls([grp_id])
			for grp_tpl in grp_tpls:
				if grp_tpl.tpl_id == tpl_id:
					break
			else:
				return jsonify(retcode=-1, retmsg='update error, templdate not bind to this group')

			receiver_group = tpl["receiver_group"]
			if Team.is_team_exist(receiver_group) == False:
				return jsonify(retcode=-1, retmsg="receiver group name is not exist")

			parent_tpls = Template.get_tpl_parent([tpl_id])
			tpl_map = Template.to_tpl_map(parent_tpls)

			# 查tpl_id关联的action
			tpls = Template.query_tpl([tpl_id])
			actions = Action.query_action([t.action_id for t in tpls])
			for action in actions:
				action.uic = receiver_group
				# 更新接收人分组信息
				Action.update_action(action.id, action.uic, action.url, action.callback, action.before_callback_sms, action.before_callback_mail, action.after_callback_sms, action.after_callback_mail)

			for strategy in tpl["strategies"]:
				operation = strategy["operation"]
				if operation == "update" or operation == "delete":
					strategy_id = strategy["id"]
				else:
					strategy_id = 0

				if operation == "add" or operation == "update":
					metric = strategy["metric"]
					tags = strategy["tags"]
					max_step = strategy["max_step"]
					priority = strategy["priority"]
					func = strategy["func"]
					op = strategy["op"]
					right_value = strategy["right_value"]
					note = strategy["note"]
					run_begin = strategy["run_begin"]
					run_end = strategy["run_end"]

				if operation == "add":
					# 增加一条告警策略
					# 相同的metric+tags，一个模块中只能有一条策略,hbs不支持多条策略
					tmp_strategies = Strategy.query_straetgy_by_uuid(tpl_id, metric, tags)
					if len(tmp_strategies) == 0: 
						strategy_id = Strategy.insert_strategy(metric, tags, max_step, priority, func, op, right_value, note, run_begin, run_end, tpl_id)
					else:
						Strategy.update_strategy(tmp_strategies[0].id, metric, tags, max_step, priority, func, op, right_value, note, run_begin, run_end, tpl_id)
				elif operation == "update":
					# 更新告警策略
					tmp_strategies = Strategy.query_strategy([strategy_id])
					if tpl_id not in tpl_map:
						return jsonify(retcode=-1, retmsg="strategy is not belong to template")
					if len(tmp_strategies) == 0 or tmp_strategies[0].tpl_id != tpl_id:
						Strategy.insert_strategy(metric, tags, max_step, priority, func, op, right_value, note, run_begin, run_end, tpl_id)
					else:
						Strategy.update_strategy(strategy_id, metric, tags, max_step, priority, func, op, right_value, note, run_begin, run_end, tpl_id)
				elif operation == "delete":
					# 删除告警策略，只有每个host定制的strategy才删除，从公共模板继承下来的，通过增加一个状态为disable的策略
					if tpl_id not in tpl_map:
						return jsonify(retcode=-1, retmsg="strategy is not belong to template")
					tmp_strategies = Strategy.query_strategy([strategy_id])
					if len(tmp_strategies) != 0 and tmp_strategies[0].tpl_id == tpl_id:
						Strategy.delete_strategy([strategy_id])
					else:
						Strategy.disable_strategy([strategy_id])
	return jsonify(retcode=0, retmsg="success")

@app.route('/api/query_user', methods=['POST'])
def query_user():
	names = request.get_json(force=True)
	users = User.query_by_name(names)
	return json.dumps([user.to_json() for user in users])

@app.route('/api/update_user', methods=['POST'])
def update_user():
	req = request.get_json(force=True)
	for user in req:
		if User.is_exist_user(user["name"]):
			User.update_user(name=user["name"], cnname=user["cnname"], email=user["email"], phone=user["phone"])
		else:
			User.add_user(name=user['name'], cnname=user['cnname'], email=user['email'], phone=user['phone'])
	return jsonify(retcode=0, retmsg='success')

@app.route('/api/delete_user', methods=['POST'])
def delete_user():
	names = request.get_json(force=True)
	User.delete_user(names)
	return jsonify(retcode=0, retmsg='success')

@app.route('/api/query_receiver_group', methods=['POST'])
def query_receiver_group():
	names = request.get_json(force=True)
	teams = Team.query_team_by_name(names)
	result = []
	for team in teams:
		team_users = TeamUser.query_team_user([team.id for team in teams])
		users = User.query_by_id([team_user.uid for team_user in team_users])
		result.append({
			'group_name': team.name,
			'members': [user.name for user in users]
		})
	
	return json.dumps(result)

@app.route('/api/update_receiver_group', methods=['POST'])
def update_receiver_group():
	req = request.get_json(force=True)
	for group_receiver in req:
		group_name = group_receiver["group_name"]
		members = group_receiver["members"]
		teams = Team.query_team_by_name([group_name])
		if len(teams) == 0:
			Team.add_team(group_name)
			teams = Team.query_team_by_name([group_name])

		users = User.query_by_name(members)
		map_name_users=dict()
		for user in users:
			map_name_users[user.name]=user

		uids=[]
		for member in members: 
			if member in map_name_users:
				uids.append(map_name_users[member].id)

		if len(teams) > 0 and len(uids) > 0:
			TeamUser.update_team_user(teams[0].id, uids)
		else:
			return jsonify(retcode=-1, retmsg="not found group name or members name")
		return jsonify(retcode=0, retmsg="success")

@app.route('/api/delete_receiver_group', methods=['POST'])
def delete_receiver_group():
	names = request.get_json(force=True)
	teams = Team.query_team_by_name(names)
	TeamUser.unbind_all_user([team.id for team in teams]);
	Team.delete_team([team.id for team in teams])
	return jsonify(retcode=0, retmsg="success")

@app.route('/api/query_data', methods=['POST'])
def query_data():
	req = request.get_json(force=True)
	begin_time = req["begin_time"]
	end_time = req["end_time"]
	cf = req["cf"]
	step = req["step"]
	endpoint_counters = []
	for host_counter in req["host_counters"]:
		endpoint_counters.append({
			'Endpoint': host_counter['host'],
			'Counter': host_counter['counter']
		})
	

	params = {
			'start': utils.date_to_sec(begin_time, '%Y-%m-%d %H:%M:%S'),
			'end': utils.date_to_sec(end_time, '%Y-%m-%d %H:%M:%S'),
			'cf': cf,
			'step': step,
			'endpoint_counters': endpoint_counters
	}

	r = requests.post(config.QUERY_PROXY_ADDR + "/api/history", data=json.dumps(params))
	if r.status_code != 200:
		return jsonify(retcode=-1, retmsg="request query_proxy failed, please conntact system admin", data=json.dumps([]));

	resp = dict()
	resp["retcode"] = 0
	resp["retmsg"] = "success"
	resp["data"] = []

	r_json = r.json()
	for host_counter in r_json["data"]:
		values = []
		if host_counter["Values"]:
			for value in host_counter["Values"]:
				values.append({
					'timestamp': utils.sec_to_date(value["timestamp"], '%Y-%m-%d %H:%M:%S'),
					'value': value['value']
				})
		resp["data"].append({
			'host': host_counter['endpoint'],
			'counter': host_counter['counter'],
			'values': values
		})

	return json.dumps(resp)

@app.route('/api/last', methods=['POST'])
def query_last():
	req = request.get_json(force=True)
	endpoint_counters = []
	for host_counter in req:
		endpoint_counters.append({
			'Endpoint': host_counter['host'],
			'Counter': host_counter['counter']
		})
	
	r = requests.post(config.QUERY_PROXY_ADDR + "/api/last", data=json.dumps(endpoint_counters))
	if r.status_code != 200:
		return jsonify(retcode=-1, retmsg="request query_proxy failed, please contact system  admin", data=json.dumps([]))
	resp = dict()
	resp["retcode"] = 0
	resp["retmsg"] = "success"
	resp["data"] = []

	r_json = r.json()
	for host_counter in r_json["data"]:
		resp["data"].append({
			'host': host_counter['endpoint'],
			'counter': host_counter['counter'],
			'value': host_counter['value']
		})
	return json.dumps(resp)

@app.route('/api/query_metric', methods=['POST'])
def query_metric():
	req = request.get_json(force=True)
	result = []
	for one in req:
		counters = pa_business.query_metric(one["host"], one["metric_key"], one["tags"])
		result.append({
			'host': one["host"],
			'tags': one["tags"],
			'metric_key': one["metric_key"],
			'counters': counters
		})
	return json.dumps(result)

@app.route('/api/query_metric_page', methods=['POST'])
def query_metric_page():
	req = request.get_json(force=True)
	host = req["host"]
	metric_key = req["metric_key"]
	tags = req["tags"]
	page_size = req["page_size"]
	current_page = req["current_page"]

	if page_size <= 0:
		return json.dumps({"host": host, "tags": tags, "metric_key": metric_key, "total_count": 0, "counters": []})

	counters = pa_business.query_metric(host, metric_key, tags)
	sorted_counters = sorted(counters, key=lambda one:one["counter"])
	dst_counters = sorted_counters[(current_page-1)*page_size:current_page*page_size]

	return json.dumps({"host": host, "tags": tags, "metric_key": metric_key, "total_count": len(counters), "counters": dst_counters})


@app.route('/api/create_app')
def create_app():
	app_name = request.args.get('app_name', '')
	type = request.args.get('type', '')
	if not app_name or not type:
		return jsonify(retcode=-1, retmsg="app_name or type is empty")
	creater = 'sys'
	pa_business.add_app(app_name, type, creater)
	return jsonify(retcode=0, retmsg="success")

@app.route('/api/init_host_monitor', methods=['POST'])
def init_host_monitor():
	req = request.get_json(force=True)
	for host in req:
		pa_business.bind_host_app(host["hostname"], host["os"], host["receiver_group"])
	return jsonify(retcode=0, retmsg="success")

@app.route('/api/init_app_monitor', methods=['POST'])
def init_app_monitor():
	req = request.get_json(force=True)
	for host in req:
		pa_business.bind_host_app(host["hostname"], host["app"], host["receiver_group"])
	return jsonify(retcode=0, retmsg="success")

@app.route('/api/add_host', methods=['POST'])
def add_host():
	hostnames = request.get_json(force=True)
	for hostname in hostnames:
		pa_business.add_host(hostname)
	return jsonify(retcode=0, retmsg="success")

@app.route('/api/del_host', methods=['POST'])
def del_host():
	hostnames = request.get_json(force=True)
	for hostname in hostnames:
		pa_business.del_host(hostname)
	return jsonify(retcode=0, retmsg="success")

@app.route('/api/unbind_app')
def unbind_app():
	hostname = request.args.get('hostname', '')
	app_name = request.args.get('app_name', '')
	if not hostname or not app_name:
		return jsonify(retcode=-1, retmsg='hostname or app_name is empty')
	pa_business.unbind_host_app(hostname, app_name)
	return jsonify(retcode=0, retmsg="success")

@app.route('/api/query_receiver_group_endpoint', methods=['POST'])
def query_receiver_group_endpoint():
	req_data = request.get_json(force=True)
	receiver_group = req_data["receiver_group"]
	actions = Action.query_action_by_recv_grp(receiver_group)
	tpls = Template.query_tpl_by_action([action.id for action in actions])
	grp_tpls = GrpTpl.grp_tpls_by_tpl([tpl.id for tpl in tpls])
	grp_hosts = GroupHost.grp_host_by_grp([grp_tpl.grp_id for grp_tpl in grp_tpls])
	hosts = Host.query_by_ids([grp_host.host_id for grp_host in grp_hosts])
	hostnames = [host.hostname for host in hosts]
	return jsonify(retcode=0, retmsg="success", endpoints=hostnames)

@app.route('/api/maintain', methods=['POST'])
def maintain_hosts():
	req_data = request.get_json(force=True)

	# 2016-11-29 00:00:00转为unix time
	maintain_begin = time.mktime(time.strptime(req_data["maintain_begin"], "%Y-%m-%d %H:%M:%S"))
	maintain_end = time.mktime(time.strptime(req_data["maintain_end"], "%Y-%m-%d %H:%M:%S"))

	hosts = req_data["hosts"]
	Host.maintain_hosts(maintain_begin, maintain_end, hosts)
	return jsonify(retcode=0, retmsg="success")

@app.route('/api/unmaintain', methods=['POST'])
def unmaintain_hosts():
	hosts = request.get_json(force=True)
	Host.unmaintain_hosts(hosts)
	return jsonify(retcode=0, retmsg="success")

@app.route('/api/query_alert', methods=['POST'])
def query_alert():
#	status = request.values.get('status', '')
#	begin_time = request.values.get('begin_time', '')
#	end_time = request.values.get('end_time', '')
#	receiver_group = request.values.get('receiver_group', '')
#	priority = request.values.get('priority', '')
#	key = request.values.get('key', '')
#	page_size = int(request.values.get('page_size', '50'))
#	current_page = int(request.values.get('current_page', '1'))
#
	req_data = request.get_json(force=True)
	status = req_data['status']
	begin_time = req_data['begin_time']
	end_time = req_data['end_time']
	receiver_group = req_data['receiver_group']
	priority = req_data['priority']
	key = req_data['key']
	if req_data['page_size'] == 0:
		page_size = 50
	else:
		page_size = req_data['page_size']

	if req_data['current_page'] == 0:
		current_page = 1
	else:
		current_page = req_data['current_page']

	(total_count, alerts) = Alert.query_alert(status, begin_time, end_time, receiver_group, priority, key, page_size, current_page)
	return json.dumps({
		"total_count": total_count,
		"page_size": page_size,
		"current_page": current_page,
		"alerts": [ alert.to_json() for alert in alerts ]
	})

@app.route('/api/add_screen', methods=['POST'])
def add_screen():
	req_data = request.get_json(force=True)
	level1 = req_data["level1"]
	level2 = req_data["level2"]
	level3 = req_data["level3"]
	creator = req_data["creator"]
	screen_id = Screen.add_screen(level1, level2, level3, creator)
	if screen_id == -1:
		return jsonify(retcode=-1, retmsg="screen already exist", screen_id=None)
	else:
		return jsonify(retcode=0, retmsg="success", screen_id=screen_id)

@app.route('/api/mod_screen', methods=['POST'])
def mod_screen():
	req_data = request.get_json(force=True)
	screen_id = req_data["screen_id"]
	level1 = req_data["level1"]
	level2 = req_data["level2"]
	level3 = req_data["level3"]
	operator = req_data["operator"]
	ret = Screen.mod_screen(screen_id, level1, level2, level3, operator)
	if ret is not None:
		return jsonify(retcode=0, retmsg="success")
	else:
		return jsonify(retcode=-1, retmsg="update screen failed")

@app.route('/api/del_screen', methods=['POST'])
def del_screen():
	req_data = request.get_json(force=True)
	screen_id = req_data['screen_id']
	operator = req_data['operator']
	count = Graph.count_by_screen_id(screen_id)
	if count > 0:
		return jsonify(retcode=-1, retmsg="can not delete not empty screen")
	Screen.del_screen(screen_id)
	return jsonify(retcode=0, retmsg="success")

@app.route('/api/query_screen', methods=['POST'])
def query_screen():
	req_data = request.get_json(force=True)
	level1s = req_data['level1']
	level2s = req_data['level2']
	level3s = req_data['level3']
	screen_ids = req_data['screen_id']
	page_size = req_data['page_size']
	current_page = req_data['current_page']

	screens = Screen.query_screen(screen_ids, level1s, level2s, level3s)

	return json.dumps({
		'retcode': 0,
		'retmsg': 'success',
		'total': len(screens),
		'screens': [screen.to_json() for screen in screens[(current_page-1)*page_size : page_size*current_page]]
		})

@app.route('/api/add_graph', methods=['POST'])
def add_graph():
	req_data = request.get_json(force=True)
	title = req_data['title']
	hosts = req_data['hosts']
	counters = req_data['counters']
	screen_id = req_data['screen_id']
	graph_type = req_data['graph_type']
	creator = req_data['creator']

	if not Screen.exist_screen(screen_id):
		return jsonify(retcode=-1, retmsg="screen not exist", graph_id=None)

	if graph_type == 'h':
		if len(hosts) > config.MAX_LINE_COUNT:
			return jsonify(retcode=-1, retmsg="host view, max host is %d" %(config.MAX_LINE_COUNT))
	elif graph_type == 'k':
		if len(counters) > config.MAX_LINE_COUNT:
			return jsonify(retcode=-1, retmsg="counter view, max counter is %d" %(config.MAX_LINE_COUNT))
	else:
		if len(hosts) * len(counters) > config.MAX_LINE_COUNT:
			return jsonify(retcode=-1, retmsg='compose view, count(host)*count(counter) maust less then %d' %(config.MAX_LINE_COUNT))

	graph_id = Graph.add_graph(title, hosts, counters, screen_id, graph_type, creator)

	return jsonify(retcode=0, retmsg="success", graph_id=graph_id)

@app.route('/api/mod_graph', methods=['POST'])
def mod_graph():
	req_data = request.get_json(force=True)
	graph_id = req_data['graph_id']
	title = req_data['title']
	hosts = req_data['hosts']
	counters = req_data['counters']
	screen_id = req_data['screen_id']
	graph_type = req_data['graph_type']
	operator = req_data['operator']

	if not Screen.exist_screen(screen_id):
		return jsonify(retcode=-1, retmsg="screen not exist", graph_id=None)

	if graph_type == 'h':
		if len(hosts) > config.MAX_LINE_COUNT:
			return jsonify(retcode=-1, retmsg="host view, max host is %d" %(config.MAX_LINE_COUNT))
	elif graph_type == 'k':
		if len(counters) > config.MAX_LINE_COUNT:
			return jsonify(retcode=-1, retmsg="counter view, max counter is %d" %(config.MAX_LINE_COUNT))
	else:
		if len(hosts) * len(counters) > config.MAX_LINE_COUNT:
			return jsonify(retcode=-1, retmsg='compose view, count(host)*count(counter) maust less then %d' %(config.MAX_LINE_COUNT))

	Graph.mod_graph(graph_id, title, hosts, counters, screen_id, graph_type, operator)

	return jsonify(retcode=0, retmsg="success")

@app.route('/api/query_screen_graph', methods=['POST'])
def query_screen_graph():
	req_data = request.get_json(force=True)
	screen_id = req_data['screen_id']
	page_size = req_data['page_size']
	current_page = req_data['current_page']

	graphs = Graph.query_graph_by_screen_id(screen_id)

	return jsonify(retcode=0, retmsg="success", total=len(graphs), graphs=[graph.to_json() for graph in graphs[(current_page-1)*page_size : current_page*page_size]])

@app.route('/api/del_graph', methods=['POST'])
def del_graph():
	req = request.get_json(force=True)
	graph_ids = req['graph_ids']
	operator = req['operator']
	if not isinstance(graph_ids, list):
		return jsonify(retcode=-1, retmsg="parameter error, must be json array")
	Graph.del_graph(graph_ids)
	return jsonify(retcode=0, retmsg="success")

@app.route('/api/query_screen_data', methods=['POST'])
def query_screen_data():
	req_data = request.get_json(force=True)
	screen_id = int(req_data['screen_id'])
	page_size = int(req_data['page_size'])
	current_page = int(req_data['current_page'])
	begin_time = req_data['begin_time']
	end_time = req_data['end_time']
	cf = req_data['cf']
	step = int(req_data['step'])

	graphs = Graph.query_graph_by_screen_id(screen_id)

	offset = (current_page - 1) * page_size

	extended_graph = pa_business.extend_graphs(graphs)

	endpoint_counters_set = set()

	for i in range(offset, offset + page_size):
		if i >= len(extended_graph):
			break
		for host in extended_graph[i].hosts:
			for counter in extended_graph[i].counters:
				endpoint_counters_set.add((host, counter))
	
	endpoint_counters_arr = []
	for endpoint_counter in endpoint_counters_set:
		endpoint_counters_arr.append({
			'Endpoint': endpoint_counter[0],
			'Counter': endpoint_counter[1]
			})

	params = {
		'start': utils.date_to_sec(begin_time, '%Y-%m-%d %H:%M:%S'),
		'end': utils.date_to_sec(end_time, '%Y-%m-%d %H:%M:%S'),
		'cf': cf,
		'step': step,
		'endpoint_counters': endpoint_counters_arr
	}

	r = requests.post(config.QUERY_PROXY_ADDR + "/api/history", data=json.dumps(params))
	if r.status_code != 200:
		return jsonify(retcode=-1, retmsg="request query_proxy failed, please conntact system admin", data=json.dumps([]));

	resp = dict()
	resp["retcode"] = 0
	resp["retmsg"] = "success"
	resp["total_count"] = len(extended_graph)
	resp["pics"] = []

	endpoint_counter_data = dict()

	r_json = r.json()
	for host_counter in r_json["data"]:
		values = []
		if host_counter["Values"]:
			for value in host_counter["Values"]:
				values.append({
					'timestamp': utils.sec_to_date(value["timestamp"], '%Y-%m-%d %H:%M:%S'),
					'value': value['value']
				})
		endpoint_counter_data[(host_counter['endpoint'], host_counter['counter'])] = values

	for i in range(offset, offset + page_size):
		if i >= len(extended_graph):
			break
		pic=dict()

		pic['title'] = extended_graph[i].title
		pic['lines'] = []
		for host in extended_graph[i].hosts:
			for counter in extended_graph[i].counters:
				line = dict()
				line['host'] = host
				line['counter'] = counter
				if endpoint_counter_data.has_key((host, counter)):
					line['values'] = endpoint_counter_data[(host, counter)]
				else:
					line['values'] = []
				pic['lines'].append(line)
		resp["pics"].append(pic)
	return json.dumps(resp)


@app.route('/api/grafana', methods=['POST'])
def query_metric_values():
	r = requests.post(config.QUERY_PROXY_ADDR + "/api/grafana", data=json.dumps(params))

@app.route('/api/grafana', methods=['GET'])
def query_hosts_metric():

