# -*- coding:utf-8 -*-

import logging
import datetime
import urllib
from flask import Flask, request, g, session, make_response, redirect

app = Flask(__name__)
app.config.from_object("frame.config")

# config log
log_formatter = '%(asctime)s\t[%(filename)s:%(lineno)d] [%(levelname)s: %(message)s]'
log_level = logging.DEBUG if app.config['DEBUG'] else logging.WARNING
logging.basicConfig(format=log_formatter, datefmt="%Y-%m-%d %H:%M:%S", level=log_level)

@app.teardown_request
def teardown_request(exception):
	from frame.store import portal_db, uic_db
	portal_db.commit()
	uic_db.commit()

from web.controller import api
