# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import uic_db

class Team(Bean):
	_tbl = 'team'
	_cols = 'id, name, resume, creator'
	_db = uic_db

	def __init__(self, id, name, resume, creator):
		self.id = id
		self.name = name
		self.resume = resume
		self.creator = creator 
	
	@classmethod
	def query_team_by_name(cls, names):
		if len(names) == 0:
			return
		where = ' name in (%s' + ',%s' * (len(names)-1) + ')'
		return cls.select_vs(where=where, params=names)

	@classmethod
	def add_team(cls, name):
		if not cls.is_team_exist(name):
			cls.insert({
				'name': name
			})

	@classmethod
	def delete_team(cls, tids):
		if len(tids) == 0:
			return
		where = 'id in (%s' + ',%s' * (len(tids)-1) + ')'
		cls.delete(where=where, params=tids)

	@classmethod
	def is_team_exist(cls, name):
		where = ' name = %s '
		return cls.exists(where=where, params=[name])
