# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import portal_db

class Template(Bean):
	_tbl = 'tpl'
	_cols = 'id, tpl_name, parent_id, action_id, create_user'
	_db = portal_db

	def __init__(self, id, tpl_name, parent_id, action_id, create_user):
		self.id = id
		self.tpl_name = tpl_name
		self.parent_id = parent_id
		self.action_id = action_id
		self.create_user = create_user

	@classmethod
	def get_tpl_parent(cls, tpl_ids):
		tpl_id_set = set()
		res_tpls = []

		cur_tpl_ids = tpl_ids
		while True:
			params = []
			for tpl_id in cur_tpl_ids:
				if tpl_id not in tpl_id_set:
					params.append(tpl_id)
			if len(params) == 0:
				break
			where = ' id in (%s' + ',%s' * (len(params) - 1) + ')'
			vs = cls.select_vs(where = where, params = params)
			cur_tpl_ids = []
			for row in vs:
				if row.parent_id != 0:
					cur_tpl_ids.append(row.parent_id)
				res_tpls.append(row)
		return res_tpls

	@classmethod
	def to_tpl_map(cls, tpls):
		tpl_map = dict()
		for tpl in tpls:
			tpl_map[tpl.id] = tpl
		return tpl_map

	@classmethod
	def query_tpl(cls, tpl_ids):
		if len(tpl_ids) == 0:
			return []
		else:
			where = ' id in (%s' + ',%s' * (len(tpl_ids) - 1) + ')'
		return cls.select_vs(where=where, params=tpl_ids)

	@classmethod
	def query_tpl_by_action(cls, action_ids):
		if len(action_ids) == 0:
			return []
		else:
			where = ' action_id in (%s' + ',%s' * (len(action_ids)-1) + ')'
		return cls.select_vs(where=where, params=action_ids)

	@classmethod
	def add_tpl(cls, tpl_name, parent_id, action_id, create_user):
		return cls.insert({
			'tpl_name': tpl_name,
			'parent_id': parent_id,
			'action_id': action_id,
			'create_user': create_user
		}) 

	@classmethod
	def del_tpl(cls, tpl_id):
		cls.delete(where='id = %s', params=[tpl_id])

