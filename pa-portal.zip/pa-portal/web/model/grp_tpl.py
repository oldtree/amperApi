# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import portal_db

class GrpTpl(Bean):
	_tbl = 'grp_tpl'
	_cols = 'grp_id, tpl_id, bind_user'
	_db = portal_db

	def __init__(self, grp_id, tpl_id, bind_user):
		self.grp_id = grp_id
		self.tpl_id = tpl_id
		self.bind_user = bind_user

	@classmethod
	def grp_tpls(cls, grp_ids):
		if len(grp_ids) > 0:
			where = " grp_id in (%s" + ',%s' * (len(grp_ids) - 1) + ") "
		else:
			return []

		vs = cls.select_vs(where=where, params=grp_ids)
		return vs

	@classmethod
	def grp_tpls_by_tpl(cls, tpl_ids):
		if len(tpl_ids) > 0:
			where = ' tpl_id in (%s' + ',%s' * (len(tpl_ids)-1) + ')'
		else:
			return []
		return cls.select_vs(where=where, params=tpl_ids)

	@classmethod
	def to_grp_tpl_map(cls, grp_tpls):
		grp_tpl_map = dict()
		for grp_tpl in grp_tpls:
			if grp_tpl.grp_id in grp_tpl_map:
				grp_tpl_map[grp_tpl.grp_id].append(grp_tpl.tpl_id)
			else:
				grp_tpl_map[grp_tpl.grp_id] = [grp_tpl.tpl_id]
		return grp_tpl_map

	@classmethod
	def add_grp_tpl(cls, grp_id, tpl_id, bind_user):
		return cls.insert({
			'grp_id': grp_id,
			'tpl_id': tpl_id,
			'bind_user': bind_user
		})
	
	@classmethod
	def del_grp_tpl(cls, grp_id, tpl_id):
		cls.delete(where='grp_id=%s and tpl_id=%s', params=[grp_id, tpl_id])
