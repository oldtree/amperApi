# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import portal_db

class Strategy(Bean):
	_tbl = 'strategy'
	_cols = 'id, metric, tags, max_step, priority, func, op, right_value, note, run_begin, run_end, tpl_id'
	_db = portal_db

	def __init__(self, id, metric, tags, max_step, priority, func, op, right_value, note, run_begin, run_end, tpl_id):
		self.id = id
		self.metric = metric
		self.tags = tags
		self.max_step = max_step
		self.priority = priority
		self.func = func
		self.op = op
		self.right_value = right_value
		self.note = note
		self.run_begin = run_begin
		self.run_end = run_end
		self.tpl_id = tpl_id
		self.deletable = True

	def to_json(self):
		return {
				'id': self.id,
				'metric': self.metric,
				'tags': self.tags,
				'max_step': self.max_step,
				'priority': self.priority,
				'func': self.func,
				'op': self.op,
				'right_value': self.right_value,
				'note': self.note,
				'run_begin': self.run_begin,
				'run_end': self.run_end,
				'tpl_id': self.tpl_id,
				'deletable': self.deletable
				}

	@classmethod
	def tpl_strategies(cls, tpl_ids):
		if len(tpl_ids) == 0:
			return []
		else: 
			where = ' tpl_id in (%s' + ',%s' * (len(tpl_ids) - 1) + ')'
		vs = cls.select_vs(where=where, params=tpl_ids)
		return vs

	@classmethod
	def to_tpl_strategy_map(cls, strategies):
		tpl_strategy_map = dict()
		for strategy in strategies:
			if strategy.tpl_id in tpl_strategy_map:
				tpl_strategy_map[strategy.tpl_id].append(strategy)
			else:
				tpl_strategy_map[strategy.tpl_id] = [strategy]
		return tpl_strategy_map

	@classmethod
	def query_strategy(cls, strategy_ids):
		if len(strategy_ids) == 0:
			return []
		where = ' id in (%s' + ',%s' * (len(strategy_ids) - 1) + ')'
		return cls.select_vs(where=where, params=strategy_ids)

	@classmethod
	def query_straetgy_by_uuid(cls, tpl_id, metric, tags):
		where = " tpl_id=%s and metric=%s and tags=%s"
		return cls.select_vs(where=where, params=[int(tpl_id), metric, tags])

	@classmethod
	def insert_strategy(cls, metric, tags, max_step, priority, func, op, right_value, note, run_begin, run_end, tpl_id):
		strategy_id = cls.insert({
			'metric': metric, 
			'tags': tags,
			'max_step': max_step,
			'priority': priority,
			'func': func, 
			'op': op,
			'right_value': right_value,
			'note': note,
			'run_begin': run_begin,
			'run_end': run_end,
			'tpl_id': tpl_id
		})
		return strategy_id

	@classmethod
	def update_strategy(cls, id, metric, tags, max_step, priority, func, op, right_value, note, run_begin, run_end, tpl_id):
		cls.update_dict({
			'metric': metric, 
			'tags': tags,
			'max_step': max_step,
			'priority': priority,
			'func': func, 
			'op': op,
			'right_value': right_value,
			'note': note,
			'run_begin': run_begin,
			'run_end': run_end,
			'tpl_id': tpl_id,
			}, 
			' id = %s ', 
			[id]
		)

	@classmethod
	def delete_strategy(cls, strategy_ids):
		if len(strategy_ids) == 0:
			return
		else:
			where = ' id in (%s' + ',%s' * (len(strategy_ids) - 1) + ')'
		cls.delete(where=where, params=strategy_ids)

	@classmethod
	def del_tpl_strategy(cls, tpl_id):
		where = 'tpl_id = %s'
		cls.delete(where=where, params=[tpl_id])

	@classmethod
	def disable_strategy(cls, strategy_ids):
		# TODO: 修改strategy的状态为不可用, 目前暂未支持
		pass

