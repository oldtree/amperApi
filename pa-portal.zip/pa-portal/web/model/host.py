# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import portal_db

class Host(Bean):
	_tbl = 'host'
	_cols = 'id, hostname, maintain_begin, maintain_end'
	_db = portal_db

	def __init__(self, id, hostname, maintain_begin, maintain_end):
		self.id = id
		self.hostname = hostname
		self.maintain_begin = maintain_begin
		self.maintain_end = maintain_end

	@classmethod
	def query_by_hostnames(cls, hostnames):
		if len(hostnames) > 0:
			where = " hostname in (%s" + ",%s" * (len(hostnames) - 1) + ") "

		vs = cls.select_vs(where=where, params=hostnames)
		return [cls(int(row.id), row.hostname, int(row.maintain_begin), int(row.maintain_end)) for row in vs]

	@classmethod
	def query_by_ids(cls, host_ids):
		if len(host_ids) == 0:
			return []
		else:
			where = 'id in (%s' + ',%s' * (len(host_ids)-1) + ')'
		return cls.select_vs(where=where, params=host_ids)

	@classmethod
	def add_host(cls, hostname):
		hostid = cls.insert({
			"hostname": hostname
		})
		return hostid

	@classmethod
	def del_host(cls, hostid):
		cls.delete(where="id = %s", params=[hostid])

	@classmethod
	def maintain_hosts(cls, maintain_begin, maintain_end, hosts):
		if len(hosts) == 0:
			return
		else:
			where = " hostname in (%s" + ", %s" * (len(hosts)-1) + ")"
		cls.update_dict({
			'maintain_begin': maintain_begin,
			'maintain_end': maintain_end
			},
			where,
			hosts)

	@classmethod 
	def unmaintain_hosts(cls, hosts):
		if len(hosts) == 0:
			return
		else:
			where = " hostname in (%s" + ", %s" * (len(hosts)-1) + ")"
		cls.update_dict({
			'maintain_begin': 0,
			'maintain_end': 0
			},
			where,
			hosts)

