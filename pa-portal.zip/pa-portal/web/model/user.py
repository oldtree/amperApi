# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import uic_db

class User(Bean):
	_tbl = 'user'
	_cols = 'id, name, cnname, email, phone'
	_db = uic_db

	def __init__(self, id, name, cnname, email, phone):
		self.id = id
		self.name = name
		self.cnname = cnname
		self.email = email
		self.phone = phone
	
	def to_json(self):
		return {
			'id': self.id,
			'name': self.name,
			'cnname': self.cnname,
			'email': self.email,
			'phone': self.phone
		}

	@classmethod
	def add_user(cls, name, cnname, email, phone, passwd='383cb060c68454b052bb99ea1ce80310'):
		# 默认密码为Paic1234
		userid = cls.insert({
			'name': name,
			'cnname': cnname,
			'email': email,
			'phone': phone,
			'passwd': passwd
			})
		return userid

	@classmethod
	def update_user(cls, name, cnname, email, phone):
		cls.update_dict({
			'cnname': cnname,
			'email': email,
			'phone': phone
			},
			where = ' name = %s ', 
			params = [name]
		)

	@classmethod
	def is_exist_user(cls, name):
		return cls.exists(where='name = %s', params=[name])
	
	@classmethod
	def delete_user(cls, names):
		if len(names) == 0:
			return
		where = 'name in (%s' + ',%s' * (len(names) - 1) + ')'
		cls.delete(where=where, params=names)

	@classmethod
	def query_by_name(cls, names):
		if len(names) == 0:
			return []
		else:
			where = 'name in (%s' + ',%s' * (len(names) - 1) + ')'
		return cls.select_vs(where=where, params=names)

	@classmethod
	def query_by_id(cls, ids):
		if len(ids) == 0:
			return []
		where = 'id in (%s' + ',%s' * (len(ids) - 1) + ')'
		return cls.select_vs(where=where, params=ids)


