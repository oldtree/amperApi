# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import uic_db

class TeamUser(Bean):
	_tbl = "rel_team_user"
	_cols = "id, tid, uid"
	_db = uic_db
	def __init__(self, id, tid, uid):
		self.id = id
		self.tid = tid
		self.uid = uid
	
	@classmethod
	def query_team_user(cls, tids):
		if len(tids) == 0:
			return []
		where = ' tid in (%s' + ',%s' * (len(tids) - 1) + ')'
		return cls.select_vs(where=where, params=tids)

	@classmethod
	def bind_team_user(cls, tid, uids):
		for uid in uids:
			cls.insert({
				'tid': tid,
				'uid': uid
			})
	
	@classmethod
	def unbind_team_user(cls, tid, uids):
		if len(uids) == 0:
			return
		where = ' tid = %s and uid in (%s' + ',%s' * (len(uids) - 1) + ')'
		params = [tid]
		params.extend(uids)
		cls.delete(where=where, params=params)

	@classmethod
	def unbind_all_user(cls, tids):
		if len(tids) == 0:
			return
		where = 'tid in (%s' + ',%s' * (len(tids)-1) + ')'
		cls.delete(where=where, params=tids)

	@classmethod
	def update_team_user(cls, tid, uids):
		where = ' tid = %s '
		vs = cls.select_vs(where=where, params=[tid])
		cls.unbind_team_user(tid, [t.uid for t in vs])

		if len(uids) > 0:
			cls.bind_team_user(tid, uids)

	@classmethod
	def to_tid_uid_map(tid_uids):
		tid_uid_map = dict()
		for tid_uid in tid_uids:
			if tid_uid.tid  in tid_uid_map:
				tid_uid_map[tid_uid.tid].append(tid_uid.uid)
			else:
				tid_uid_map[tid_uid.tid] = [tid_uid.uid]
