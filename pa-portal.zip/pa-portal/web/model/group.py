# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import portal_db

class Group(Bean):
	_tbl = "grp"
	_cols = "id, grp_name, create_user"
	_db = portal_db

	def __init__(self, id, grp_name, create_user):
		self.id = id
		self.grp_name = grp_name
		self.create_user = create_user

	@classmethod
	def query_by_grpnames(cls, grpnames):
		if len(grpnames) == 0:
			return []
		where = " grp_name in (%s" + ",%s" * (len(grpnames) - 1) + ")"
		vs = cls.select_vs(where=where, params=grpnames)
		return vs

	@classmethod
	def add_group(cls, grpname):
		grpid = cls.insert({
			'grp_name': grpname, 
			'create_user': 'sys'
		})
		return grpid

	@classmethod
	def del_group(cls, grp_id):
		cls.delete(where="id=%s", params=[grp_id])
