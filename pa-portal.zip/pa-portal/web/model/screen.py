# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import portal_db

class Screen(Bean):
	_tbl = "screen"
	_cols = "id, level1, level2, level3, creator, operator, modify"
	_db = portal_db

	def __init__(self, id, level1, level2, level3, creator, operator, modify):
		self.id = id
		self.level1 = level1
		self.level2 = level2
		self.level3 = level3
		self.creator = creator
		self.operator = operator
		self.modify = modify

	def to_json(self):
		return {
				'id': self.id,
				'level1': self.level1,
				'level2': self.level2,
				'level3': self.level3,
				'creator': self.creator, 
				'operator': self.operator,
				'modify': self.modify.strftime('%Y-%m-%d %H:%M:%S')
				}

	@classmethod
	def add_screen(cls, level1, level2, level3, creator):
		where = 'level1=%s and level2=%s and level3=%s'
		if cls.exists(where=where, params=[level1, level2, level3]):
			return -1

		screen_id = cls.insert({
			'level1': level1,
			'level2': level2,
			'level3': level3,
			'creator': creator,
			'operator': creator
		})
		return screen_id

	@classmethod
	def mod_screen(cls, id, level1, level2, level3, operator):
		where = 'id = %s'
		return cls.update_dict(data={'level1': level1, 'level2': level2, 'level3':level3, 'operator': operator}, where=where, params=[id])

	@classmethod
	def del_screen(cls, id):
		where = 'id = %s'
		cls.delete(where=where, params=[id])

	@classmethod
	def query_screen(cls, ids, level1s, level2s, level3s):
		where = ''
		params = []
		if len(ids) > 0:
			where += 'id in (%s' + ',%s' * (len(ids)-1) + ')'
			params.extend(ids)
		if len(level1s) > 0:
			if where != '':
				where += ' and '
			#where += 'level1 in (%s' + ',%s' * (len(level1s)-1) + ')'
			where += '(level1 like %s' + ' or level1 like %s'*(len(level1s)-1) + ')'
			params.extend(level1s)
		if len(level2s) > 0: 
			if where != '':
				where += ' and '
			#where += 'level2 in (%s' + ',%s' * (len(level2s)-1) + ')'
			where += '(level2 like %s' + ' or level2 like %s'*(len(level2s)-1) + ')'
			params.extend(level2s)
		if level3s != "":
			if where != '':
				where += ' and '
			where += 'level3 like %s'
			params.append('%' + level3s + '%')
		return cls.select_vs(where=where, params=params, order="id desc")

	@classmethod
	def exist_screen(cls, screen_id):
		where = 'id = %s'
		return cls.exists(where=where, params=[screen_id])

