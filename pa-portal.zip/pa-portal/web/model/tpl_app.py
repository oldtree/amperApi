# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import portal_db

class TplApp(Bean):
	_tbl = "tpl_app"
	_cols = "id, tpl_id, app_id"
	_db = portal_db

	def __init__(self, id, tpl_id, app_id):
		self.id = id
		self.tpl_id = tpl_id
		self.app_id = app_id

	@classmethod
	def query_tpl_app(cls, tpl_ids):
		if len(tpl_ids) == 0:
			return []
		else:
			where = " tpl_id in (%s" + ",%s" * (len(tpl_ids)-1) + ")"
		vs = cls.select_vs(where=where, params=tpl_ids)
		return vs

	@classmethod
	def to_tpl_app_map(cls, tpl_apps):
		tpl_app_map = dict()
		for tpl_app in tpl_apps:
			tpl_app_map[tpl_app.tpl_id] = tpl_app.app_id
		return tpl_app_map

	@classmethod
	def add_tpl_app(cls, tpl_id, app_id):
		return cls.insert({
			'tpl_id': tpl_id,
			'app_id': app_id
		})

	@classmethod
	def del_tpl_app(cls, tpl_id, app_id):
		cls.delete(where="tpl_id=%s and app_id=%s", params=[tpl_id, app_id])
