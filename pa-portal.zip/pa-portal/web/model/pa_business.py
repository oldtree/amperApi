# -*- coding:utf-8 -*-

from web.model.host import Host
from web.model.app import App
from web.model.group import Group
from web.model.group_host import GroupHost
from web.model.grp_tpl import GrpTpl
from web.model.template import Template
from web.model.tpl_app import TplApp
from web.model.action import Action
from web.model.strategy import Strategy
from web.model.metric_info import MetricInfo
from web.model.graph import Graph
import requests
from frame import config
import json

'''
公共的template, 为common_<app_name>开头
每台主机自动创建的template，为default_tpl_<app_name>_<hostname>
每台主机自动创建的group，为default_group_<hostname>
'''

def add_host(hostname):
	'''
	增加一台主机，如果发现host表里没有，就加一条
	'''
	hosts = Host.query_by_hostnames([hostname])
	if len(hosts) > 0:
		return hosts[0].id
	return Host.add_host(hostname)

def del_host(hostname):
	'''
	删除一台主机，把自动创建的default_group_<hostname>机器分组,自动创建的各类应用的监控模板default_tpl_<app_name>_<hostname>都一起删除了
	'''
	hosts = Host.query_by_hostnames([hostname])
	if len(hosts) > 0: 
		Host.del_host(hosts[0].id)
		GroupHost.del_by_host_id(hosts[0].id)

	groups = Group.query_by_grpnames(["default_group_" + hostname])
	if len(groups) == 0:
		return
	Group.del_group(groups[0].id)
	grp_tpls = GrpTpl.grp_tpls([groups[0].id])
	for grp_tpl in grp_tpls:
		GrpTpl.del_grp_tpl(grp_tpl.grp_id, grp_tpl.tpl_id)
		tpls = Template.query_tpl([grp_tpl.tpl_id])
		Template.del_tpl(grp_tpl.tpl_id)
		Strategy.del_tpl_strategy(grp_tpl.tpl_id)
		if len(tpls) > 0 and tpls[0].action_id != 0:
			Action.del_action(tpls[0].action_id)

def add_app(app_name, type, creater):
	'''
	增加一类应用，为这类应用创建一个通用的模板common_<app_name>
	'''
	app = App.query_app_by_name(app_name)
	if app:
		return
	common_tpl_name = "common_" + app_name
	tpl_id = Template.add_tpl(common_tpl_name, 0, 0, creater)
	app_id = App.add_app(app_name, type, tpl_id, creater)
	TplApp.add_tpl_app(tpl_id, app_id)

def add_default_grp(hostname):
	'''
	机器首次关联监控模板时，给自动建一个group，default_group_<hostname>
	'''
	def_grp_name = "default_group_" + hostname
	groups = Group.query_by_grpnames([def_grp_name])
	if len(groups) > 0:
		return groups[0].id
	return Group.add_group(def_grp_name)

def bind_host_grp(host_id, grp_id):
	if GroupHost.exist_grp_host(grp_id, host_id):
		return
	GroupHost.add_grp_host(grp_id, host_id)

def bind_host_app(hostname, app_name, receiver_group):
	'''
	给主机关联应用模板，首次关联时，需要创建一个默认的group default_group_<hostname>
	给这个机器创建一个独立的应用监控模板，从公共模板中继也承过来
	将先将的模板关联到default_group_<hostname>这个分组上面
	'''
	app = App.query_app_by_name(app_name)
	if not app:
		return
	host_id = add_host(hostname)
	grp_id = add_default_grp(hostname)
	bind_host_grp(host_id, grp_id)
	grp_tpls = GrpTpl.grp_tpls([grp_id])
	tpl_apps = TplApp.query_tpl_app([grp_tpl.tpl_id for grp_tpl in grp_tpls])
	for tpl_app in tpl_apps:
		if tpl_app.app_id == app.id:
			return
	action_id = Action.add_action(receiver_group, "", 0, 0, 0, 0, 0)
	def_tpl_name = "default_tpl_" + app_name + "_" + hostname
	tpl_id = Template.add_tpl(def_tpl_name, app.tpl_id, action_id, 'sys')
	TplApp.add_tpl_app(tpl_id, app.id)
	GrpTpl.add_grp_tpl(grp_id, tpl_id, 'sys')

def unbind_host_app(hostname, app_name):
	'''
	给主机解绑一个应用,将创建的这台主机的独立的监控模板给删除了
	'''
	app = App.query_app_by_name(app_name)
	if not app:
		return
	host_id = add_host(hostname)
	grp_id = add_default_grp(hostname)
	grp_tpls = GrpTpl.grp_tpls([grp_id])
	tpl_apps = TplApp.query_tpl_app([grp_tpl.tpl_id for grp_tpl in grp_tpls])
	for tpl_app in tpl_apps:
		if tpl_app.app_id == app.id:
			tpls = Template.query_tpl([tpl_app.tpl_id])
			if len(tpls) > 0 and tpls[0].action_id != 0:
				Action.del_action(tpls[0].action_id)
			Template.del_tpl(tpl_app.tpl_id)
			GrpTpl.del_grp_tpl(grp_id, tpl_app.tpl_id)
			TplApp.del_tpl_app(tpl_app.tpl_id, tpl_app.app_id)
			return


def query_strategy(endpoints):
	hosts = Host.query_by_hostnames(endpoints)
	group_hosts = GroupHost.group_ids([host.id for host in hosts])
	host_group_map = GroupHost.to_host_group_map(group_hosts)

	grp_tpls = GrpTpl.grp_tpls([grp_host.grp_id for grp_host in group_hosts])
	grp_tpl_map = GrpTpl.to_grp_tpl_map(grp_tpls)

	tpls = Template.get_tpl_parent([grp_tpl.tpl_id for grp_tpl in grp_tpls])
	tpl_map = Template.to_tpl_map(tpls)

	strategies = Strategy.tpl_strategies([tpl.id for tpl in tpls])
	tpl_strategy_map = Strategy.to_tpl_strategy_map(strategies)

	tpl_apps = TplApp.query_tpl_app([grp_tpl.tpl_id for grp_tpl in grp_tpls])
	tpl_app_map = TplApp.to_tpl_app_map(tpl_apps)

	apps = App.query_app([tpl_app.app_id for tpl_app in tpl_apps])
	app_map = App.to_app_map(apps)

	actions = Action.query_action([tpl.action_id for tpl in tpls])
	action_map = Action.to_action_map(actions)

	result = []
	for host in hosts:
		host_templates = dict()
		host_templates["host"] = host.hostname
		host_templates["host_id"] = host.id
		host_templates["templates"] = []
		if host.id not in host_group_map:
			continue
		for grp_id in host_group_map[host.id]:
			if grp_id not in grp_tpl_map:
				continue
			for tpl_id in grp_tpl_map[grp_id]:
				template = dict()
				template["grp_id"] = grp_id
				template["tpl_id"] = tpl_id
				if tpl_id in tpl_map and tpl_map[tpl_id].action_id in action_map:
					template["receiver_group"] = action_map[tpl_map[tpl_id].action_id].uic
				else:
					template["receiver_group"] = ""
				if tpl_id in tpl_app_map and tpl_app_map[tpl_id] in app_map:
					template["tpl_type"] = app_map[tpl_app_map[tpl_id]].name
				else:
					template["tpl_type"] = "unknow"
				strategies = calc_tpl_strategy(tpl_id, tpl_map, tpl_strategy_map)
				template["strategies"] = strategies
				host_templates["templates"].append(template)
				result.append(host_templates)
	return result

# page页从1开始，page_size要求>0
def query_strategy_by_key(endpoint, metric_key, page_size, current_page):
	tmp_result = query_strategy([endpoint])
	if len(tmp_result) != 1 or page_size <= 0: 
		return {"total_count": 0, "host":endpoint, "host_id": 0, "templates":[]}
	one_tmp_result = tmp_result[0]
	total_count = 0
	dst_templates = []
	current_idx = 0

	for template in one_tmp_result["templates"]:
		one_dst_template = {"tpl_id": template["tpl_id"], "tpl_type": template["tpl_type"], "grp_id": template["grp_id"], "receiver_group": template["receiver_group"], "strategies": []}
		tmp_strategies = template["strategies"]
		dst_strategies = []
		map_strategy = dict()
		for strategy in tmp_strategies:
			counter = strategy["metric"] + "/" + strategy["tags"]
			if metric_key in counter or metric_key == "":
				map_strategy[counter] = strategy
		sorted_counter_strategy_tuple = sorted(map_strategy.items())
		total_count += len(sorted_counter_strategy_tuple)

		for (counter, strategy) in sorted_counter_strategy_tuple:
			if current_idx >= (current_page - 1) * page_size and (current_idx < current_page * page_size):
				dst_strategies.append(strategy)
			current_idx += 1
		one_dst_template["strategies"] = dst_strategies
		dst_templates.append(one_dst_template)
	return {"total_count": total_count, "host": endpoint, "host_id": one_tmp_result["host_id"], "templates": dst_templates}


def calc_tpl_strategy(tpl_id, tpl_map, tpl_strategy_map):
	strategies = []
	cur_tpl_id = tpl_id
	strategy_uuid_set = set()

	while True:
		if cur_tpl_id == 0 or cur_tpl_id not in tpl_map:
			break

		if cur_tpl_id in tpl_strategy_map:
			for strategy in tpl_strategy_map[cur_tpl_id]:
				uuid = strategy.metric + '/' + strategy.tags
				if uuid in strategy_uuid_set:
					continue
				strategy_uuid_set.add(uuid)
				if strategy.tpl_id != tpl_id:
					strategy.deletable = False
				strategies.append(strategy.to_json())

		cur_tpl_id = tpl_map[cur_tpl_id].parent_id
	return strategies

def query_metric(host, metric_key, tags):
	r = requests.get(config.QUERY_PROXY_ADDR + "/api/counters", params={'endpoints': json.dumps([host]), "q": metric_key, "limit": config.MAX_COUNTER_CNT})
	r_json = r.json()
	counter_infos = r_json["data"]
	counter_infos = filter_counter(counter_infos, tags)
	counters = []

	for counter_info in counter_infos:
		fields = counter_info["Counter"].split('/', 1)
		metric = fields[0]
		metric_info = MetricInfo.query_metric_info(host, metric)
		if metric_info:
			counter = {"counter": counter_info["Counter"], "type": counter_info["Type"], "step": counter_info["Step"], "unit": metric_info.unit, "description": metric_info.description}
		else:
			counter = {"counter": counter_info["Counter"], "type": counter_info["Type"], "step": counter_info["Step"], "unit": "", "description": ""}
		counters.append(counter)
	return counters

def filter_counter(counter_infos, raw_tags):
	if raw_tags != "":
		require_tags = raw_tags.split(',')
	else:
		require_tags = []
	result = []
	for counter_info in counter_infos:
		counter = counter_info["Counter"]
		fields = counter.split('/', 1)
		if len(require_tags) > 0:
			if len(fields) > 1:
				tag_set = set(fields[1].split(','))
				for tag in require_tags:
					if tag not in tag_set:
						break
				else:
					result.append(counter_info)
		else:
			result.append(counter_info)
	return result

def query_screen_data(screen_id, page_size, current_page, begin_time, end_time, cf):
	graphs = Graph.query_graph_by_screen_id(screen_id)

def extend_graphs(graphs):
	res_graphs = []
	for graph in graphs:
		if len(graph.hosts) == 0 or len(graph.counters) == 0:
			continue
		# 主机视角
		if graph.graph_type == "h":
			for counter in graph.counters:
				tmp_graph = Graph(graph.id, graph.title, graph.hosts, [counter], graph.screen_id, graph.graph_type, graph.creator, graph.operator, graph.modify)
				res_graphs.append(tmp_graph)
		# 监控项视角
		elif graph.graph_type == "k":
			for host in graph.hosts:
				tmp_graph = Graph(graph.id, graph.title, [host], graph.counters, graph.screen_id, graph.graph_type, graph.creator, graph.operator, graph.modify)
				res_graphs.append(tmp_graph)
		# 组合视角
		else:
			res_graphs.append(graph)
	return res_graphs
