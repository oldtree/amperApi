#-*- coding:utf8 -*-

from .bean import Bean
from frame.store import portal_db

class Graph(Bean):
	_tbl = "graph"
	_cols = "id, title, hosts, counters, screen_id, graph_type, creator, operator, modify"
	_db = portal_db

	def to_json(self):
		return {
				'id': self.id,
				'title': self.title,
				'hosts': self.hosts,
				'counters': self.counters,
				'screen_id': self.screen_id,
				'graph_type': self.graph_type,
				'creator': self.creator,
				'operator': self.operator,
				'modify': self.modify.strftime('%Y-%m-%d %H:%M:%S')
				}

	def __init__(self, id, title, hosts, counters, screen_id, graph_type, creator, operator, modify):
		self.id = id
		self.title = title
		self.hosts = hosts
		self.counters = counters
		self.screen_id = screen_id
		self.graph_type = graph_type
		self.creator = creator
		self.operator = operator
		self.modify = modify

	@classmethod
	def add_graph(cls, title, hosts, counters, screen_id, graph_type, creator):
		str_hosts = "|".join(hosts)
		str_counters = "|".join(counters)

		return cls.insert({
			'title': title,
			'hosts': str_hosts,
			'counters': str_counters,
			'screen_id': screen_id,
			'graph_type': graph_type,
			'creator': creator,
			'operator': creator
		})

	@classmethod
	def mod_graph(cls, id, title, hosts, counters, screen_id, graph_type, operator):
		str_hosts = "|".join(hosts)
		str_counters = "|".join(counters)

		where = 'id = %s'
		cls.update_dict(data={
			'title': title,
			'hosts': str_hosts,
			'counters': str_counters,
			'screen_id': screen_id,
			'graph_type': graph_type,
			'operator': operator
			},
			where=where,
			params=[id]
		)

	@classmethod
	def del_graph(cls, ids):
		if len(ids) == 0:
			return
		where = 'id in (%s' + ',%s' * (len(ids)-1) + ')'
		cls.delete(where=where, params=ids)

	@classmethod
	def query_graph_by_screen_id(cls, screen_id):
		where = 'screen_id = %s'
		rows = cls.select(where=where, params=[screen_id], order='id desc')
		return [Graph(row[0], row[1], row[2].split('|'), row[3].split('|'), row[4], row[5], row[6], row[7], row[8]) for row in rows]

	@classmethod
	def count_by_screen_id(cls, screen_id):
		where = 'screen_id = %s'
		return cls.total(where=where, params=[screen_id])

