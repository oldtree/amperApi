# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import portal_db

class Action(Bean):
	_tbl = 'action'
	_cols = 'id, uic, url, callback, before_callback_sms, before_callback_mail, after_callback_sms, after_callback_mail'
	_db = portal_db

	def __init__(self, id, uic, url, callback, before_callback_sms, before_callback_mail, after_callback_sms, after_callback_mail):
		self.id = id
		self.uic = uic
		self.url = url
		self.callback = callback
		self.before_callback_sms = before_callback_sms
		self.before_callback_mail = before_callback_mail
		self.after_callback_sms = after_callback_sms
		self.after_callback_mail = after_callback_mail

	@classmethod
	def query_action(cls, action_ids):
		if len(action_ids) == 0:
			return []
		else:
			where = ' id in (%s' + ',%s' * (len(action_ids)-1) + ')'
		return cls.select_vs(where=where, params=action_ids)

	@classmethod
	def query_action_by_recv_grp(cls, receiver_group):
		where = ' uic = %s '
		return cls.select_vs(where=where, params=[receiver_group])

	@classmethod
	def to_action_map(cls, actions):
		action_map = dict()
		for action in actions:
			action_map[action.id] = action
		return action_map

	@classmethod
	def update_action(cls, id, uic, url, callback, before_callback_sms, before_callback_mail, after_callback_sms, after_callback_mail):
		cls.update_dict(
			{
				"uic": uic,
				"url": url,
				"callback": callback,
				"before_callback_sms": before_callback_sms,
				"before_callback_mail": before_callback_mail,
				"after_callback_sms": after_callback_sms,
				"after_callback_mail": after_callback_mail
			}, 
			"id = %s", 
			[id]
		)
	
	@classmethod
	def add_action(cls, uic, url, callback, before_callback_sms, before_callback_mail, after_callback_sms, after_callback_mail):
		return cls.insert({
			'uic': uic,
			'url': url,
			'callback': callback,
			'before_callback_sms': before_callback_sms,
			'before_callback_mail': before_callback_mail,
			'after_callback_sms': after_callback_sms,
			'after_callback_mail': after_callback_mail
		})
	
	@classmethod
	def del_action(cls, action_id):
		cls.delete(where='id=%s', params=[action_id])

