# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import alarm_db
import json

class Alert(Bean):
	_tbl = "alerts"
	_cols = "id, event_id, endpoint, counter, max_step, current_step, priority, expression_id, strategy_id, content, note, status, team, event_time, ifnull(recovery_time, '0000-00-00 00:00:00')"
	_db = alarm_db

	def __init__(self, id, event_id, endpoint, counter, max_step, current_step, priority, expression_id, strategy_id, content, note, status, receiver_group, event_time, recovery_time):
		self.id = id
		self.event_id = event_id
		self.endpoint = endpoint
		self.counter = counter
		self.max_step = max_step
		self.current_step = current_step
		self.priority = priority
		self.expression_id = expression_id
		self.strategy_id = strategy_id
		self.content = content
		self.note = note
		self.status = status
		self.receiver_group = receiver_group
		self.event_time = event_time
		self.recovery_time = recovery_time

	def to_json(self):
		return {
			'id': self.id,
			'event_id': self.event_id,
			'endpoint': self.endpoint,
			'counter': self.counter,
			'max_step': self.max_step,
			'current_step': self.current_step,
			'priority': self.priority,
			'expression_id': self.expression_id,
			'strategy_id': self.strategy_id,
			'content': self.content,
			'note': self.note,
			'status': self.status,
			'receiver_group': self.receiver_group,
			'event_time': str(self.event_time),
			'recovery_time': str(self.recovery_time)
		}
	
	@classmethod
	def query_alert(cls, status, begin_time, end_time, receiver_group, priority, key, page_size, current_page):
		where = ''
		params = []
		if status != "":
			status_array = status.split(',')
			where += 'status in (%s' + (len(status_array)-1) * ',%s' + ')'
			params.extend(status_array)

		if begin_time != "":
			if where != "":
				where += " and "
			where += ' event_time >= %s'
			params.append(begin_time)

		if end_time != "":
			if where != "":
				where += " and "
			where += ' event_time <= %s'
			params.append(end_time)

		if receiver_group != "":
			if where != "":
				where += " and "
			receiver_group_array = receiver_group.split(',')
			where += ' team in (%s' + ',%s' * (len(receiver_group_array)-1) + ')'
			params.extend(receiver_group_array)

		if priority != "":
			if where != "":
				where += " and "
			priority_array = priority.split(',')
			where += 'priority in (%s' + ',%s'  * (len(priority_array)-1) + ')'
			params.extend(priority_array)

		if key != "":
			if where != "":
				where += " and "
			where += ' content like %s'
			params.append('%' + key + '%')

		total_count = cls.total(where=where, params=params)

		vs = cls.select_vs(where=where, order='id desc', params=params, page=current_page, limit=page_size)
		return total_count, vs
