# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import portal_db

class App(Bean):
	_tbl = "app"
	_cols = "id, name, type, tpl_id, creater"
	_db = portal_db

	def __init__(self, id, name, type, tpl_id, creater):
		self.id = id
		self.name = name
		self.type = type
		self.tpl_id = tpl_id
		self.creater = creater
	
	@classmethod
	def query_app(cls, app_ids):
		if len(app_ids) == 0:
			return []
		else:
			where = " id in (%s" + ",%s" * (len(app_ids) - 1) + ")"

		vs = cls.select_vs(where=where, params=app_ids)
		return vs

	@classmethod
	def add_app(cls, name, type, tpl_id, creater):
		return cls.insert({
			'name': name,
			'type': type,
			'tpl_id': tpl_id,
			'creater': creater
		})

	@classmethod
	def query_app_by_name(cls, name):
		where = "name = %s"
		row = cls.read(where=where,params=[name])
		if row:
			return row
		else:
			return None

	@classmethod
	def to_app_map(cls, apps):
		app_map = dict()
		for app in apps:
			app_map[app.id] = app
		return app_map
