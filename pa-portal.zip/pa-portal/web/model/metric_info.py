# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import portal_db

class MetricInfo(Bean):
	_tbl = 'metric_info'
	_cols = 'id, metric, endpoint, unit, description, creator'
	_db = portal_db

	def __init__(self, id, metric, endpoint, unit, description, creator):
		self.id = id
		self.metric = metric
		self.endpoint = endpoint
		self.unit = unit
		self.description = description
		self.creator = creator

	@classmethod
	def query_metric_info(cls, endpoint, metric):
		where = "(endpoint='' or endpoint=%s) and metric=%s"
		return cls.read(where=where, params=[endpoint, metric])
