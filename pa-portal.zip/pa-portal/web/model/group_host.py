# -*- coding:utf-8 -*-

from .bean import Bean
from frame.store import portal_db

class GroupHost(Bean):
	_tbl = 'grp_host'
	_cols = 'grp_id, host_id'
	_db = portal_db

	def __init__(self, grp_id, host_id):
		self.grp_id = grp_id
		self.host_id = host_id
	
	@classmethod
	def group_ids(cls, host_ids):
		if len(host_ids) == 0:
			return []
		else:
			where = ' host_id in (%s' + ',%s' * (len(host_ids) - 1) + ') '
		vs = cls.select_vs(where=where, params=host_ids)
		return vs

	@classmethod
	def grp_host_by_grp(cls, grp_ids):
		if len(grp_ids) == 0:
			return []
		else:
			where = ' grp_id in (%s' + ',%s' * (len(grp_ids)-1) + ')'
		return cls.select_vs(where=where, params=grp_ids)

	@classmethod
	def exist_grp_host(cls, grp_id, host_id):
		return cls.exists(where=" host_id = %s and grp_id = %s", params=[host_id, grp_id])

	@classmethod
	def add_grp_host(cls, grp_id, host_id):
		cls.insert({
			'grp_id': grp_id,
			'host_id': host_id
		})

	@classmethod
	def del_grp_host(cls, grp_id, host_id):
		cls.delete(where='grp_id = %s and host_id = %s', params=[grp_id, host_id])

	@classmethod
	def del_by_host_id(cls, host_id):
		cls.delete(where='host_id = %s', params=[host_id])

	@classmethod
	def to_host_group_map(cls, group_hosts):
		host_group_map = dict()
		for group_host in group_hosts:
			if group_host.host_id in host_group_map:
				host_group_map[group_host.host_id].append(group_host.grp_id)
			else:
				host_group_map[group_host.host_id] = [group_host.grp_id]
		return host_group_map
