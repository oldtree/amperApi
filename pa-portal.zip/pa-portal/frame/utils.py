# -*- coding:utf-8  -*-

import datetime
import time

def date_to_sec(date, format):
	d = datetime.datetime.strptime(date, format)
	return int(time.mktime(d.timetuple()))

def sec_to_date(sec, format):
	return time.strftime(format, time.localtime(sec))
