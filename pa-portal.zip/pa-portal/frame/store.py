# -*- coding:utf8 -*-
import logging
import MySQLdb
from frame import config

def connect_db(host, port, user, password, db):
	try:
		conn = MySQLdb.connect(
				host=host,
				port=port,
				user=user,
				passwd=password,
				db=db,
				use_unicode=True,
				charset="utf8")
		return conn
	except Exception, e:
		print "Fatal: connect db failed:%s" % e
		return None

class DB(object):
	def __init__(self, host, port, user, password, db):
		self.host = host
		self.port = port
		self.user = user
		self.password = password
		self.db = db
		self._conn = connect_db(host, port, user, password, db)
	
	def connect(self):
		if self._conn is None:
			self._conn = connect_db(self.host, self.port, self.user, self.password, self.db)
		return self._conn

	def execute(self, *a, **kw):
		cursor = kw.pop('cursor', None)
		try:
			cursor = cursor or self._conn.cursor()
			cursor.execute(*a, **kw)
		except (AttributeError, MySQLdb.OperationalError):
			self._conn and self._conn.close()
			self._conn = None
			self.connect()
			cursor = self._conn.cursor()
			cursor.execute(*a, **kw)
		return cursor

	# insert one record in a transaction
	# return last id
	def insert(self, *a, **kw):
		try:
			cursor = self.execute(*a, **kw)
			row_id = cursor.lastrowid
			self.commit()
			return row_id
		except MySQLdb.IntegrityError:
			self.rollback()
	
	# update in a transaction
	# return affected row count
	def update(self, *a, **kw):
		cursor = None
		try:
			cursor = self.execute(*a, **kw)
			self.commit()
			row_count = cursor.rowcount
			return row_count
		except MySQLdb.IntegrityError:
			self.rollback()
	
	def query_all(self, *a, **kw):
		cursor = self.execute(*a, **kw)
		return cursor.fetchall()

	def query_one(self, *a, **kw):
		rows = self.query_all(*a, **kw)
		if rows:
			return rows[0]
		else:
			return None
	
	def query_column(self, *a, **kw):
		rows = self.query_all(*a, **kw)
		if rows:
			return [row[0] for row in rows]
		else:
			return []

	def commit(self):
		if self._conn:
			try:
				self._conn.commit()
			except MySQLdb.OperationalError:
				self._conn and self._conn.close()
				self._conn = None
				self.connect()
				self._conn and self._conn.commit()
	
	def rollback(self):
		if self._conn:
			try:
				self._conn.rollback()
			except MySQLdb.OperationalError:
				self._conn and self._conn.rollback()


portal_db = DB(config.PORTAL_DB_HOST, 
		config.PORTAL_DB_PORT, 
		config.PORTAL_DB_USER, 
		config.PORTAL_DB_PASS, 
		config.PORTAL_DB_NAME)

uic_db = DB(config.UIC_DB_HOST, 
		config.UIC_DB_PORT, 
		config.UIC_DB_USER, 
		config.UIC_DB_PASS, 
		config.UIC_DB_NAME)

alarm_db = DB(config.ALARM_DB_HOST,
		config.ALARM_DB_PORT,
		config.ALARM_DB_USER,
		config.ALARM_DB_PASS,
		config.ALARM_DB_NAME)
